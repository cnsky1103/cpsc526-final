#!/bin/bash

cd ../files
rm -rf *

pkill master
pkill server