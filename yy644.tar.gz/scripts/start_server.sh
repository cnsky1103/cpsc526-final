#!/bin/bash

cd ../server/server
# go run server.go
go run server.go &> server_run.log &