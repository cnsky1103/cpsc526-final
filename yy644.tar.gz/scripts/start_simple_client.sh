#!/bin/bash

cd ../client
go run client.go